#include "height_scan_publisher.h"

#include "param.h"

#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#include <algorithm>
#include <cmath>
#include <iostream>

HeightScanPublisher::~HeightScanPublisher()
{
    close_socket();
}

void HeightScanPublisher::close_socket()
{
    if (socket_fd_ >= 0) {
        ::close(socket_fd_);
        socket_fd_ = -1;
    }
}

bool HeightScanPublisher::init(const param::SimulationConfig& cfg)
{
    enabled_ = (cfg.enable_height_scan_pub == 1);
    if (!enabled_) {
        std::cout << "[height_scan_pub] disabled by config" << std::endl;
        return true;
    }

    dest_ip_ = cfg.height_scan_dest_ip;
    dest_port_ = cfg.height_scan_dest_port;

    publish_hz_ = std::max(1.0, cfg.height_scan_publish_hz);
    publish_period_ = 1.0 / publish_hz_;

    resolution_ = std::max(1.0e-4, cfg.height_scan_resolution);
    size_x_ = std::max(resolution_, cfg.height_scan_size_x);
    size_y_ = std::max(resolution_, cfg.height_scan_size_y);
    ray_origin_z_ = cfg.height_scan_ray_origin_z;

    obs_offset_ = cfg.height_scan_offset;
    clip_min_ = static_cast<float>(cfg.height_scan_clip_min);
    clip_max_ = static_cast<float>(cfg.height_scan_clip_max);
    if (clip_min_ > clip_max_) {
        std::swap(clip_min_, clip_max_);
    }

    // IsaacLab grid includes end-point: arange(start, end + 1e-9, step)
    nx_ = static_cast<int>(std::floor(size_x_ / resolution_ + 1.0e-9)) + 1;
    ny_ = static_cast<int>(std::floor(size_y_ / resolution_ + 1.0e-9)) + 1;

    buffer_.assign(static_cast<std::size_t>(nx_ * ny_), 0.0f);

    close_socket();
    socket_fd_ = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (socket_fd_ < 0) {
        std::cerr << "[height_scan_pub] failed to create UDP socket" << std::endl;
        enabled_ = false;
        return false;
    }

    dest_addr_ = {};
    dest_addr_.sin_family = AF_INET;
    dest_addr_.sin_port = htons(static_cast<uint16_t>(dest_port_));
    if (::inet_pton(AF_INET, dest_ip_.c_str(), &dest_addr_.sin_addr) != 1) {
        std::cerr << "[height_scan_pub] invalid destination IP: " << dest_ip_ << std::endl;
        close_socket();
        enabled_ = false;
        return false;
    }

    std::cout << "[height_scan_pub] enabled -> udp://" << dest_ip_ << ":" << dest_port_ << ", dim="
              << (nx_ * ny_) << " (" << nx_ << "x" << ny_ << "), hz=" << publish_hz_
              << ", size=(" << size_x_ << "," << size_y_ << "), res=" << resolution_ << std::endl;

    return true;
}

bool HeightScanPublisher::resolve_body_id(const mjModel* m)
{
    if (model_ptr_ == m && base_body_id_ >= 0) {
        return true;
    }

    model_ptr_ = m;
    base_body_id_ = mj_name2id(m, mjOBJ_BODY, "base_link");
    if (base_body_id_ < 0) {
        base_body_id_ = mj_name2id(m, mjOBJ_BODY, "torso_link");
    }

    if (base_body_id_ < 0) {
        std::cerr << "[height_scan_pub] base_link/torso_link not found in MJCF" << std::endl;
        return false;
    }

    return true;
}

float HeightScanPublisher::sample_height(const mjModel* m, const mjData* d, double wx, double wy, double base_z) const
{
    mjtNum pnt[3] = {
        static_cast<mjtNum>(wx),
        static_cast<mjtNum>(wy),
        static_cast<mjtNum>(base_z + ray_origin_z_)
    };
    static const mjtNum vec[3] = {0.0, 0.0, -1.0};

    // static geoms only, exclude robot body tree.
    // Restrict to geom-group 0 to mimic IsaacLab height_scanner mesh sampling over terrain.
    static const mjtByte terrain_group_mask[mjNGROUP] = {1, 0, 0, 0, 0, 0};
    mjtNum dist = mj_ray(m, d, pnt, vec, terrain_group_mask, /*flg_static=*/1, base_body_id_, nullptr);

    float h = 0.0f;
    if (dist >= 0.0) {
        const mjtNum hit_z = pnt[2] + dist * vec[2];
        h = static_cast<float>(base_z - hit_z - obs_offset_);
    }

    return std::clamp(h, clip_min_, clip_max_);
}

void HeightScanPublisher::try_publish(const mjModel* m, const mjData* d)
{
    if (!enabled_ || !m || !d || socket_fd_ < 0) {
        return;
    }

    if (!resolve_body_id(m)) {
        return;
    }

    if (d->time + 1.0e-12 < last_pub_sim_time_ + publish_period_) {
        return;
    }

    const mjtNum* base_pos = d->xpos + 3 * base_body_id_;
    const mjtNum* base_mat = d->xmat + 9 * base_body_id_;
    const double base_x = static_cast<double>(base_pos[0]);
    const double base_y = static_cast<double>(base_pos[1]);
    const double base_z = static_cast<double>(base_pos[2]);

    // yaw-only alignment, same as IsaacLab ray_alignment="yaw"
    const double yaw = std::atan2(static_cast<double>(base_mat[3]), static_cast<double>(base_mat[0]));
    const double cy = std::cos(yaw);
    const double sy = std::sin(yaw);

    const double x0 = -0.5 * size_x_;
    const double y0 = -0.5 * size_y_;

    std::size_t idx = 0;
    // ordering="xy": outer loop y, inner loop x
    for (int iy = 0; iy < ny_; ++iy) {
        const double ly = y0 + iy * resolution_;
        for (int ix = 0; ix < nx_; ++ix) {
            const double lx = x0 + ix * resolution_;
            const double wx = base_x + cy * lx - sy * ly;
            const double wy = base_y + sy * lx + cy * ly;
            buffer_[idx++] = sample_height(m, d, wx, wy, base_z);
        }
    }

    const ssize_t expected_bytes = static_cast<ssize_t>(buffer_.size() * sizeof(float));
    const ssize_t sent = ::sendto(
        socket_fd_,
        reinterpret_cast<const char*>(buffer_.data()),
        static_cast<size_t>(expected_bytes),
        0,
        reinterpret_cast<const sockaddr*>(&dest_addr_),
        sizeof(dest_addr_));

    if (sent != expected_bytes) {
        static std::size_t warn_counter = 0;
        if ((warn_counter++ % 500) == 0) {
            std::cerr << "[height_scan_pub] sendto size mismatch: sent " << sent << " / " << expected_bytes
                      << std::endl;
        }
    }

    last_pub_sim_time_ = d->time;
}
