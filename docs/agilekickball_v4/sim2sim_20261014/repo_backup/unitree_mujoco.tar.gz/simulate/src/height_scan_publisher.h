#pragma once

#include <mujoco/mujoco.h>

#include <netinet/in.h>

#include <string>
#include <vector>

namespace param {
struct SimulationConfig;
}

class HeightScanPublisher {
public:
    HeightScanPublisher() = default;
    ~HeightScanPublisher();

    HeightScanPublisher(const HeightScanPublisher&) = delete;
    HeightScanPublisher& operator=(const HeightScanPublisher&) = delete;

    bool init(const param::SimulationConfig& cfg);
    void try_publish(const mjModel* m, const mjData* d);

private:
    void close_socket();
    bool resolve_body_id(const mjModel* m);
    float sample_height(const mjModel* m, const mjData* d, double wx, double wy, double base_z) const;

private:
    bool enabled_ = false;
    int socket_fd_ = -1;
    sockaddr_in dest_addr_{};

    std::string dest_ip_ = "127.0.0.1";
    int dest_port_ = 9876;

    double publish_hz_ = 50.0;
    double publish_period_ = 0.02;
    double last_pub_sim_time_ = -1e9;

    double resolution_ = 0.1;
    double size_x_ = 1.6;
    double size_y_ = 1.0;
    double ray_origin_z_ = 20.0;

    double obs_offset_ = 0.5;
    float clip_min_ = -1.0f;
    float clip_max_ = 1.0f;

    int nx_ = 0;
    int ny_ = 0;

    const mjModel* model_ptr_ = nullptr;
    int base_body_id_ = -1;

    std::vector<float> buffer_;
};
