#pragma once

#include <boost/program_options.hpp>
#include <filesystem>
#include <iostream>
#include <yaml-cpp/yaml.h>

namespace param
{

inline struct SimulationConfig
{
    std::string robot;
    std::filesystem::path robot_scene;

    int domain_id;
    std::string interface;

    int use_joystick;
    std::string joystick_type;
    std::string joystick_device;
    int joystick_bits;

    int print_scene_information;

    int enable_elastic_band;
    int band_attached_link = 0;

    // Height-scan UDP publisher (for S2S with policies using height_scan obs)
    int enable_height_scan_pub = 0;
    std::string height_scan_dest_ip = "127.0.0.1";
    int height_scan_dest_port = 9876;
    double height_scan_publish_hz = 50.0;
    double height_scan_resolution = 0.1;
    double height_scan_size_x = 1.6;
    double height_scan_size_y = 1.0;
    double height_scan_ray_origin_z = 20.0;
    double height_scan_offset = 0.5;
    double height_scan_clip_min = -1.0;
    double height_scan_clip_max = 1.0;

    void load_from_yaml(const std::string& filename)
    {
        auto cfg = YAML::LoadFile(filename);
        try {
            robot = cfg["robot"].as<std::string>();
            robot_scene = cfg["robot_scene"].as<std::string>();
            domain_id = cfg["domain_id"].as<int>();
            interface = cfg["interface"].as<std::string>();
            use_joystick = cfg["use_joystick"].as<int>();
            joystick_type = cfg["joystick_type"].as<std::string>();
            joystick_device = cfg["joystick_device"].as<std::string>();
            joystick_bits = cfg["joystick_bits"].as<int>();
            print_scene_information = cfg["print_scene_information"].as<int>();
            enable_elastic_band = cfg["enable_elastic_band"].as<int>();

            if (cfg["enable_height_scan_pub"]) {
                enable_height_scan_pub = cfg["enable_height_scan_pub"].as<int>();
            }
            if (cfg["height_scan_dest_ip"]) {
                height_scan_dest_ip = cfg["height_scan_dest_ip"].as<std::string>();
            }
            if (cfg["height_scan_dest_port"]) {
                height_scan_dest_port = cfg["height_scan_dest_port"].as<int>();
            }
            if (cfg["height_scan_publish_hz"]) {
                height_scan_publish_hz = cfg["height_scan_publish_hz"].as<double>();
            }
            if (cfg["height_scan_resolution"]) {
                height_scan_resolution = cfg["height_scan_resolution"].as<double>();
            }
            if (cfg["height_scan_size_x"]) {
                height_scan_size_x = cfg["height_scan_size_x"].as<double>();
            }
            if (cfg["height_scan_size_y"]) {
                height_scan_size_y = cfg["height_scan_size_y"].as<double>();
            }
            if (cfg["height_scan_ray_origin_z"]) {
                height_scan_ray_origin_z = cfg["height_scan_ray_origin_z"].as<double>();
            }
            if (cfg["height_scan_offset"]) {
                height_scan_offset = cfg["height_scan_offset"].as<double>();
            }
            if (cfg["height_scan_clip_min"]) {
                height_scan_clip_min = cfg["height_scan_clip_min"].as<double>();
            }
            if (cfg["height_scan_clip_max"]) {
                height_scan_clip_max = cfg["height_scan_clip_max"].as<double>();
            }
        }
        catch (const std::exception& e)
        {
            std::cerr << e.what() << '\n';
            exit(EXIT_FAILURE);
        }
    }
} config;

/* ---------- Command Line Parameters ---------- */
namespace po = boost::program_options;

//※ This function must be called at the beginning of main() function
inline po::variables_map helper(int argc, char** argv)
{
    po::options_description desc("Unitree Mujoco");
    desc.add_options()
        ("help,h", "Show help message")
        ("domain_id,i", po::value<int>(&config.domain_id), "DDS domain ID; -i 0")
        ("network,n", po::value<std::string>(&config.interface), "DDS network interface; -n eth0")
        ("robot,r", po::value<std::string>(&config.robot), "Robot type; -r go2")
        ("scene,s", po::value<std::filesystem::path>(&config.robot_scene), "Robot scene file; -s scene_terrain.xml");

    po::variables_map vm;
    po::store(po::parse_command_line(argc, argv, desc), vm);
    po::notify(vm);

    if (vm.count("help"))
    {
        std::cout << desc << std::endl;
        exit(0);
    }

    return vm;
}

} // namespace param
