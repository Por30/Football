#pragma once

#include "Types.h"
#include "param.h"
#include "FSM/BaseState.h"
#include "isaaclab/devices/keyboard/keyboard.h"
#include "unitree_joystick_dsl.hpp"
#include <cctype>

class FSMState : public BaseState
{
public:
    FSMState(int state, std::string state_string) 
    : BaseState(state, state_string) 
    {
        spdlog::info("Initializing State_{} ...", state_string);

        auto transitions = param::config["FSM"][state_string]["transitions"];

        if(transitions)
        {
            auto transition_map = transitions.as<std::map<std::string, std::string>>();

            for(auto it = transition_map.begin(); it != transition_map.end(); ++it)
            {
                std::string target_fsm = it->first;
                if(!FSMStringMap.right.count(target_fsm))
                {
                    spdlog::warn("FSM State_'{}' not found in FSMStringMap!", target_fsm);
                    continue;
                }

                int fsm_id = FSMStringMap.right.at(target_fsm);

                std::string condition = it->second;
                auto key_check = make_keyboard_check(condition);
                if (key_check) {
                    registered_checks.emplace_back(std::make_pair(key_check, fsm_id));
                } else {
                    unitree::common::dsl::Parser p(condition);
                    auto ast = p.Parse();
                    auto func = unitree::common::dsl::Compile(*ast);
                    registered_checks.emplace_back(
                        std::make_pair(
                            [func]()->bool{ return func(FSMState::lowstate->joystick); },
                            fsm_id
                        )
                    );
                }
            }
        }

        // register for all states
        registered_checks.emplace_back(
            std::make_pair(
                []()->bool{ return lowstate->isTimeout(); },
                FSMStringMap.right.at("Passive")
            )
        );
    }

    void pre_run()
    {
        lowstate->update();
        if(keyboard) keyboard->update();
    }

    void post_run()
    {
        lowcmd->unlockAndPublish();
    }

    static std::unique_ptr<LowCmd_t> lowcmd;
    static std::shared_ptr<LowState_t> lowstate;
    static std::shared_ptr<Keyboard> keyboard;

private:
    static inline std::string trim(const std::string& s)
    {
        std::size_t b = 0;
        std::size_t e = s.size();
        while (b < e && std::isspace(static_cast<unsigned char>(s[b]))) {
            ++b;
        }
        while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) {
            --e;
        }
        return s.substr(b, e - b);
    }

    // Keyboard condition syntax:
    //   key(1).on_pressed
    //   key(2).pressed
    //   key(1)
    static inline std::function<bool()> make_keyboard_check(const std::string& raw_condition)
    {
        const std::string condition = trim(raw_condition);
        if (condition.rfind("key(", 0) != 0) {
            return {};
        }

        const std::size_t close_pos = condition.find(')');
        if (close_pos == std::string::npos || close_pos <= 4) {
            throw std::runtime_error("Invalid keyboard transition syntax: " + condition);
        }
        const std::string key_name = condition.substr(4, close_pos - 4);

        std::string suffix;
        if (close_pos + 1 < condition.size()) {
            suffix = condition.substr(close_pos + 1);
        }
        suffix = trim(suffix);
        if (suffix.empty()) {
            suffix = ".on_pressed";
        }

        if (suffix == ".pressed") {
            return [key_name]() -> bool {
                return FSMState::keyboard && FSMState::keyboard->key() == key_name;
            };
        }
        if (suffix == ".on_pressed") {
            return [key_name]() -> bool {
                return FSMState::keyboard &&
                       FSMState::keyboard->on_pressed &&
                       FSMState::keyboard->key() == key_name;
            };
        }

        throw std::runtime_error("Unsupported keyboard transition suffix: " + suffix);
    }
};
