// Copyright (c) 2025, Unitree Robotics Co., Ltd.
// All rights reserved.

#pragma once

#include <array>
#include <cmath>

#include "isaaclab/envs/manager_based_rl_env.h"

namespace isaaclab
{
namespace mdp
{

REGISTER_OBSERVATION(base_ang_vel)
{
    auto & asset = env->robot;
    auto & data = asset->data.root_ang_vel_b;
    return std::vector<float>(data.data(), data.data() + data.size());
}

REGISTER_OBSERVATION(projected_gravity)
{
    auto & asset = env->robot;
    auto & data = asset->data.projected_gravity_b;
    return std::vector<float>(data.data(), data.data() + data.size());
}

REGISTER_OBSERVATION(joint_pos)
{
    auto & asset = env->robot;
    std::vector<float> data;

    std::vector<int> joint_ids;
    try {
        joint_ids = params["asset_cfg"]["joint_ids"].as<std::vector<int>>();
    } catch(const std::exception& e) {
    }

    if(joint_ids.empty())
    {
        data.resize(asset->data.joint_pos.size());
        for(size_t i = 0; i < asset->data.joint_pos.size(); ++i)
        {
            data[i] = asset->data.joint_pos[i];
        }
    }
    else
    {
        data.resize(joint_ids.size());
        for(size_t i = 0; i < joint_ids.size(); ++i)
        {
            data[i] = asset->data.joint_pos[joint_ids[i]];
        }
    }

    return data;
}

REGISTER_OBSERVATION(joint_pos_rel)
{
    auto & asset = env->robot;
    std::vector<float> data;

    data.resize(asset->data.joint_pos.size());
    for(size_t i = 0; i < asset->data.joint_pos.size(); ++i) {
        data[i] = asset->data.joint_pos[i] - asset->data.default_joint_pos[i];
    }

    try {
        std::vector<int> joint_ids;
        joint_ids = params["asset_cfg"]["joint_ids"].as<std::vector<int>>();
        if(!joint_ids.empty()) {
            std::vector<float> tmp_data;
            tmp_data.resize(joint_ids.size());
            for(size_t i = 0; i < joint_ids.size(); ++i){
                tmp_data[i] = data[joint_ids[i]];
            }
            data = tmp_data;
        }
    } catch(const std::exception& e) {
    
    }

    return data;
}

REGISTER_OBSERVATION(joint_vel_rel)
{
    auto & asset = env->robot;
    auto data = asset->data.joint_vel;

    try {
        const std::vector<int> joint_ids = params["asset_cfg"]["joint_ids"].as<std::vector<int>>();

        if(!joint_ids.empty()) {
            data.resize(joint_ids.size());
            for(size_t i = 0; i < joint_ids.size(); ++i) {
                data[i] = asset->data.joint_vel[joint_ids[i]];
            }
        }
    } catch(const std::exception& e) {
    }
    return std::vector<float>(data.data(), data.data() + data.size());
}

REGISTER_OBSERVATION(last_action)
{
    auto data = env->action_manager->action();
    return std::vector<float>(data.data(), data.data() + data.size());
};

REGISTER_OBSERVATION(velocity_commands)
{
    std::vector<float> obs(3);
    auto & joystick = env->robot->data.joystick;

    const auto cfg = env->cfg["commands"]["base_velocity"]["ranges"];

    float deadzone = 0.0f;
    float smoothing_alpha = 1.0f;
    float gain_lin_x_pos = 1.0f;
    float gain_lin_x_neg = 1.0f;
    float gain_lin_y = 1.0f;
    float gain_ang_z = 1.0f;
    try {
        if (params["deadzone"]) {
            deadzone = params["deadzone"].as<float>();
        }
        if (params["smoothing_alpha"]) {
            smoothing_alpha = params["smoothing_alpha"].as<float>();
        }
        if (params["gain_lin_x_pos"]) {
            gain_lin_x_pos = params["gain_lin_x_pos"].as<float>();
        }
        if (params["gain_lin_x_neg"]) {
            gain_lin_x_neg = params["gain_lin_x_neg"].as<float>();
        }
        if (params["gain_lin_y"]) {
            gain_lin_y = params["gain_lin_y"].as<float>();
        }
        if (params["gain_ang_z"]) {
            gain_ang_z = params["gain_ang_z"].as<float>();
        }
    } catch (const std::exception&) {
    }

    deadzone = std::max(0.0f, deadzone);
    smoothing_alpha = std::clamp(smoothing_alpha, 0.0f, 1.0f);
    gain_lin_x_pos = std::clamp(gain_lin_x_pos, 0.0f, 5.0f);
    gain_lin_x_neg = std::clamp(gain_lin_x_neg, 0.0f, 5.0f);
    gain_lin_y = std::clamp(gain_lin_y, 0.0f, 5.0f);
    gain_ang_z = std::clamp(gain_ang_z, 0.0f, 5.0f);

    auto apply_deadzone = [deadzone](float v) {
        return (std::abs(v) < deadzone) ? 0.0f : v;
    };

    float cmd_x = apply_deadzone(static_cast<float>(joystick->ly()));
    float cmd_y = apply_deadzone(static_cast<float>(-joystick->lx()));
    float cmd_yaw = apply_deadzone(static_cast<float>(-joystick->rx()));

    if (cmd_x >= 0.0f) {
        cmd_x *= gain_lin_x_pos;
    } else {
        cmd_x *= gain_lin_x_neg;
    }
    cmd_y *= gain_lin_y;
    cmd_yaw *= gain_ang_z;

    obs[0] = std::clamp(cmd_x, cfg["lin_vel_x"][0].as<float>(), cfg["lin_vel_x"][1].as<float>());
    obs[1] = std::clamp(cmd_y, cfg["lin_vel_y"][0].as<float>(), cfg["lin_vel_y"][1].as<float>());
    obs[2] = std::clamp(cmd_yaw, cfg["ang_vel_z"][0].as<float>(), cfg["ang_vel_z"][1].as<float>());

    if (smoothing_alpha < 1.0f) {
        static std::array<float, 3> prev = {0.0f, 0.0f, 0.0f};
        for (int i = 0; i < 3; ++i) {
            obs[i] = smoothing_alpha * obs[i] + (1.0f - smoothing_alpha) * prev[i];
            prev[i] = obs[i];
        }
    }

    return obs;
}

REGISTER_OBSERVATION(gait_phase)
{
    float period = params["period"].as<float>();
    float delta_phase = env->step_dt * (1.0f / period);

    env->global_phase += delta_phase;
    env->global_phase = std::fmod(env->global_phase, 1.0f);

    std::vector<float> obs(2);
    obs[0] = std::sin(env->global_phase * 2 * M_PI);
    obs[1] = std::cos(env->global_phase * 2 * M_PI);
    return obs;
}

}
}
