# go2real Climb policy folder

Expected files:
- `exported/policy.onnx`
- `params/deploy.yaml`

You can either:
1. Keep this local template folder and copy your Climb `policy.onnx` into `exported/`.
2. Set `FSM.Velocity.policy_dir` in `config/config.yaml` to your external policy directory
   (for example from IsaacLab logs), as long as it contains `exported/policy.onnx`
   and `params/deploy.yaml`.

## Height-scan UDP input

The deploy loop expects `height_scan` on UDP (`0.0.0.0:9876` by default), with either:
- Binary float32 packet of exactly 187 values (748 bytes), or
- ASCII list of 187 floats separated by commas/spaces/newlines.

If packets are stale, the observation falls back to cached/default values.

## Quick local test sender

```bash
cd deploy/robots/go2real
python3 tools/height_scan_udp_sender.py --host 127.0.0.1 --port 9876 --dim 187 --hz 30 --format binary
```

## Real LiDAR bridge (recommended for real robot)

Use DDS bridge below to convert real PointCloud2 into IsaacLab-compatible `height_scan` and stream to UDP.

```bash
cd deploy/robots/go2real/build
./go2_lidar_height_bridge \
  --network eno1 \
  --topic rt/utlidar/cloud \
  --lowstate-topic rt/lowstate \
  --udp-host 127.0.0.1 \
  --udp-port 9876 \
  --publish-hz 50
```

Optional official switch command before bridge:

```bash
cd deploy/robots/go2real
python3 tools/utlidar_switch.py --network eno1 --state ON
```

Then run controller in another terminal:

```bash
cd deploy/robots/go2real/build
./go2real_ctrl --network eno1
```

Or run both with one command:

```bash
cd deploy/robots/go2real
./tools/run_go2real_with_lidar.sh eno1
```

Notes:
- If your LiDAR topic/frame differs, change `--topic` and `--lidar-pos/--lidar-rpy-deg`.
- If IMU is unavailable, run with `--use-imu 0` (less consistent on roll/pitch terrain).
- If you only have ROS topic (no DDS), use `tools/height_scan_lidar_bridge.py` as a fallback.
- Default bridge assumes Unitree `utlidar_lidar` frame is FRD and converts to FLU (`--lidar-rpy-deg 180 0 0`).
- Output is 187 float32 values (`17x11`) with IsaacLab convention:
  `h = base_z - hit_z - 0.5`, clip to `[-1, 1]`, ordering `xy`.
