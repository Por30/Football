#pragma once

#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

class HeightScanReceiver
{
public:
    HeightScanReceiver(std::string bind_address, int port, int expected_dim);
    ~HeightScanReceiver();

    HeightScanReceiver(const HeightScanReceiver&) = delete;
    HeightScanReceiver& operator=(const HeightScanReceiver&) = delete;

    std::vector<float> get_latest(
        std::size_t dim,
        float timeout_s,
        float default_value,
        bool hold_last_on_timeout,
        bool* fresh = nullptr
    );

    const std::string& bind_address() const { return bind_address_; }
    int port() const { return port_; }
    int expected_dim() const { return expected_dim_; }

private:
    void run_loop();
    std::vector<float> parse_packet(const char* data, std::size_t len) const;

private:
    std::string bind_address_;
    int port_ = 0;
    int expected_dim_ = 0;
    int sock_fd_ = -1;

    std::atomic<bool> running_{false};
    std::thread thread_;

    mutable std::mutex mutex_;
    std::vector<float> latest_;
    std::chrono::steady_clock::time_point last_update_{};
    bool has_data_ = false;
};
