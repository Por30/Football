#include "FSM/CtrlFSM.h"
#include "FSM/State_Passive.h"
#include "FSM/State_FixStand.h"
#include "FSM/State_RLBase.h"

std::unique_ptr<LowCmd_t> FSMState::lowcmd = nullptr;
std::shared_ptr<LowState_t> FSMState::lowstate = nullptr;
std::shared_ptr<Keyboard> FSMState::keyboard = nullptr;

void init_fsm_state()
{
    auto lowcmd_sub = std::make_shared<unitree::robot::go2::subscription::LowCmd>();
    usleep(0.2 * 1e6);
    if (!lowcmd_sub->isTimeout()) {
        spdlog::critical("The other process is using the lowcmd channel, please close it first.");
        unitree::robot::go2::shutdown();
    }

    FSMState::lowcmd = std::make_unique<LowCmd_t>();
    FSMState::lowstate = std::make_shared<LowState_t>();
    FSMState::keyboard = std::make_shared<Keyboard>();

    spdlog::info("Waiting for connection to robot...");
    FSMState::lowstate->wait_for_connection();
    spdlog::info("Connected to robot.");
}

int main(int argc, char** argv)
{
    auto vm = param::helper(argc, argv);

    // Override default config with crawl-specific FSM/policy if provided.
    const auto crawl_cfg = param::config_dir / "config_crawl.yaml";
    if (std::filesystem::exists(crawl_cfg)) {
        param::config = YAML::LoadFile(crawl_cfg.string());
        spdlog::info("Loaded crawl config: {}", crawl_cfg.string());
    } else {
        spdlog::warn("config_crawl.yaml not found, fallback to config.yaml");
    }

    std::cout << " --- Unitree Robotics --- \n";
    std::cout << "     Go2 Crawl Controller (height_scan enabled)\n";

    unitree::robot::ChannelFactory::Instance()->Init(0, vm["network"].as<std::string>());

    init_fsm_state();

    auto fsm = std::make_unique<CtrlFSM>(param::config["FSM"]);
    fsm->start();

    std::cout << "Press [LT + A] to enter FixStand mode.\n";
    std::cout << "Then press [1] for Climb policy, [2] for Crawl policy.\n";

    while (true)
    {
        sleep(1);
    }

    return 0;
}
