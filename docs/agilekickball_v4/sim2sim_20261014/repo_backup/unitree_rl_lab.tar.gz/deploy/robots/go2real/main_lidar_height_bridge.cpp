#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <memory>
#include <mutex>
#include <limits>
#include <string>
#include <thread>
#include <vector>

#include <unitree/idl/go2/LowState_.hpp>
#include <unitree/idl/ros2/PointCloud2_.hpp>
#include <unitree/robot/channel/channel_factory.hpp>
#include <unitree/robot/channel/channel_subscriber.hpp>

namespace {

using PointCloudMsg = sensor_msgs::msg::dds_::PointCloud2_;
using LowStateMsg = unitree_go::msg::dds_::LowState_;

struct Config {
    std::string network = "";
    std::string topic = "rt/utlidar/cloud";
    std::string lowstate_topic = "rt/lowstate";
    std::string udp_host = "127.0.0.1";
    int udp_port = 9876;
    double publish_hz = 50.0;
    double stats_interval = 1.0;

    double size_x = 1.6;
    double size_y = 1.0;
    double resolution = 0.1;
    double offset = 0.5;
    float clip_min = -1.0f;
    float clip_max = 1.0f;

    double min_range = 0.05;
    double max_range = 3.0;
    double z_min = -2.0;
    double z_max = 1.0;

    bool use_imu = true;
    double lidar_pos[3] = {0.0, 0.0, 0.0};
    // Unitree utlidar_lidar frame is typically FRD (x-forward, y-right, z-down).
    // IsaacLab height scan expects FLU (x-forward, y-left, z-up), i.e. roll=180 deg.
    double lidar_rpy_deg[3] = {180.0, 0.0, 0.0};
    bool hold_last_grid = true;
};

inline bool starts_with(const std::string& s, const std::string& p) {
    return s.size() >= p.size() && s.compare(0, p.size(), p) == 0;
}

inline int parse_int(const char* s, int fallback) {
    if (!s) {
        return fallback;
    }
    char* end = nullptr;
    long v = std::strtol(s, &end, 10);
    if (!end || *end != '\0') {
        return fallback;
    }
    return static_cast<int>(v);
}

inline double parse_double(const char* s, double fallback) {
    if (!s) {
        return fallback;
    }
    char* end = nullptr;
    double v = std::strtod(s, &end);
    if (!end || *end != '\0') {
        return fallback;
    }
    return v;
}

void print_usage(const char* prog) {
    std::cout << "Usage: " << prog
              << " [--network <iface>] [--topic <rt/utlidar/cloud>] [--lowstate-topic <rt/lowstate>]\n"
                 "       [--udp-host <ip>] [--udp-port <9876>]\n"
                 "       [--publish-hz <50>] [--size-x <1.6>] [--size-y <1.0>] [--resolution <0.1>]\n"
                 "       [--offset <0.5>] [--clip-min <-1>] [--clip-max <1>] [--use-imu <0|1>]\n"
                 "       [--lidar-pos x y z] [--lidar-rpy-deg r p y] [--hold-last-grid <0|1>]\n"
                 "Defaults: lidar_rpy_deg=180 0 0 (Unitree FRD -> FLU).\n";
}

void parse_args(int argc, char** argv, Config& cfg) {
    for (int i = 1; i < argc; ++i) {
        const std::string arg(argv[i]);
        if (arg == "--help" || arg == "-h") {
            print_usage(argv[0]);
            std::exit(0);
        }
        if ((arg == "--network" || arg == "-n") && i + 1 < argc) {
            cfg.network = argv[++i];
            continue;
        }
        if (starts_with(arg, "--network=")) {
            cfg.network = arg.substr(std::strlen("--network="));
            continue;
        }
        if (arg == "--topic" && i + 1 < argc) {
            cfg.topic = argv[++i];
            continue;
        }
        if (starts_with(arg, "--topic=")) {
            cfg.topic = arg.substr(std::strlen("--topic="));
            continue;
        }
        if (arg == "--lowstate-topic" && i + 1 < argc) {
            cfg.lowstate_topic = argv[++i];
            continue;
        }
        if (starts_with(arg, "--lowstate-topic=")) {
            cfg.lowstate_topic = arg.substr(std::strlen("--lowstate-topic="));
            continue;
        }
        if (arg == "--udp-host" && i + 1 < argc) {
            cfg.udp_host = argv[++i];
            continue;
        }
        if (starts_with(arg, "--udp-host=")) {
            cfg.udp_host = arg.substr(std::strlen("--udp-host="));
            continue;
        }
        if (arg == "--udp-port" && i + 1 < argc) {
            cfg.udp_port = parse_int(argv[++i], cfg.udp_port);
            continue;
        }
        if (starts_with(arg, "--udp-port=")) {
            cfg.udp_port = parse_int(arg.c_str() + std::strlen("--udp-port="), cfg.udp_port);
            continue;
        }
        if (arg == "--publish-hz" && i + 1 < argc) {
            cfg.publish_hz = parse_double(argv[++i], cfg.publish_hz);
            continue;
        }
        if (starts_with(arg, "--publish-hz=")) {
            cfg.publish_hz = parse_double(arg.c_str() + std::strlen("--publish-hz="), cfg.publish_hz);
            continue;
        }
        if (arg == "--stats-interval" && i + 1 < argc) {
            cfg.stats_interval = parse_double(argv[++i], cfg.stats_interval);
            continue;
        }
        if (starts_with(arg, "--stats-interval=")) {
            cfg.stats_interval = parse_double(arg.c_str() + std::strlen("--stats-interval="), cfg.stats_interval);
            continue;
        }
        if (arg == "--size-x" && i + 1 < argc) {
            cfg.size_x = parse_double(argv[++i], cfg.size_x);
            continue;
        }
        if (arg == "--size-y" && i + 1 < argc) {
            cfg.size_y = parse_double(argv[++i], cfg.size_y);
            continue;
        }
        if (arg == "--resolution" && i + 1 < argc) {
            cfg.resolution = parse_double(argv[++i], cfg.resolution);
            continue;
        }
        if (arg == "--offset" && i + 1 < argc) {
            cfg.offset = parse_double(argv[++i], cfg.offset);
            continue;
        }
        if (arg == "--clip-min" && i + 1 < argc) {
            cfg.clip_min = static_cast<float>(parse_double(argv[++i], cfg.clip_min));
            continue;
        }
        if (arg == "--clip-max" && i + 1 < argc) {
            cfg.clip_max = static_cast<float>(parse_double(argv[++i], cfg.clip_max));
            continue;
        }
        if (arg == "--min-range" && i + 1 < argc) {
            cfg.min_range = parse_double(argv[++i], cfg.min_range);
            continue;
        }
        if (arg == "--max-range" && i + 1 < argc) {
            cfg.max_range = parse_double(argv[++i], cfg.max_range);
            continue;
        }
        if (arg == "--z-min" && i + 1 < argc) {
            cfg.z_min = parse_double(argv[++i], cfg.z_min);
            continue;
        }
        if (arg == "--z-max" && i + 1 < argc) {
            cfg.z_max = parse_double(argv[++i], cfg.z_max);
            continue;
        }
        if (arg == "--use-imu" && i + 1 < argc) {
            cfg.use_imu = (parse_int(argv[++i], 1) != 0);
            continue;
        }
        if (arg == "--lidar-pos" && i + 3 < argc) {
            cfg.lidar_pos[0] = parse_double(argv[++i], cfg.lidar_pos[0]);
            cfg.lidar_pos[1] = parse_double(argv[++i], cfg.lidar_pos[1]);
            cfg.lidar_pos[2] = parse_double(argv[++i], cfg.lidar_pos[2]);
            continue;
        }
        if (arg == "--lidar-rpy-deg" && i + 3 < argc) {
            cfg.lidar_rpy_deg[0] = parse_double(argv[++i], cfg.lidar_rpy_deg[0]);
            cfg.lidar_rpy_deg[1] = parse_double(argv[++i], cfg.lidar_rpy_deg[1]);
            cfg.lidar_rpy_deg[2] = parse_double(argv[++i], cfg.lidar_rpy_deg[2]);
            continue;
        }
        if (arg == "--hold-last-grid" && i + 1 < argc) {
            cfg.hold_last_grid = (parse_int(argv[++i], 1) != 0);
            continue;
        }
        if (starts_with(arg, "--hold-last-grid=")) {
            cfg.hold_last_grid = (parse_int(arg.c_str() + std::strlen("--hold-last-grid="), 1) != 0);
            continue;
        }
    }

    if (cfg.publish_hz < 1.0) {
        cfg.publish_hz = 1.0;
    }
    if (cfg.stats_interval < 0.2) {
        cfg.stats_interval = 0.2;
    }
    if (cfg.resolution <= 1.0e-4) {
        cfg.resolution = 0.1;
    }
    if (cfg.size_x < cfg.resolution) {
        cfg.size_x = cfg.resolution;
    }
    if (cfg.size_y < cfg.resolution) {
        cfg.size_y = cfg.resolution;
    }
    if (cfg.clip_min > cfg.clip_max) {
        std::swap(cfg.clip_min, cfg.clip_max);
    }
}

struct Mat3 {
    float m[3][3];
};

Mat3 rpy_to_rot(float roll, float pitch, float yaw) {
    const float cr = std::cos(roll), sr = std::sin(roll);
    const float cp = std::cos(pitch), sp = std::sin(pitch);
    const float cy = std::cos(yaw), sy = std::sin(yaw);
    Mat3 R{};
    R.m[0][0] = cy * cp;
    R.m[0][1] = cy * sp * sr - sy * cr;
    R.m[0][2] = cy * sp * cr + sy * sr;
    R.m[1][0] = sy * cp;
    R.m[1][1] = sy * sp * sr + cy * cr;
    R.m[1][2] = sy * sp * cr - cy * sr;
    R.m[2][0] = -sp;
    R.m[2][1] = cp * sr;
    R.m[2][2] = cp * cr;
    return R;
}

Mat3 quat_wxyz_to_rot(float w, float x, float y, float z) {
    const float n = std::sqrt(w * w + x * x + y * y + z * z);
    if (n < 1.0e-9f) {
        Mat3 I{};
        I.m[0][0] = I.m[1][1] = I.m[2][2] = 1.0f;
        return I;
    }
    w /= n;
    x /= n;
    y /= n;
    z /= n;
    Mat3 R{};
    R.m[0][0] = 1.0f - 2.0f * (y * y + z * z);
    R.m[0][1] = 2.0f * (x * y - z * w);
    R.m[0][2] = 2.0f * (x * z + y * w);
    R.m[1][0] = 2.0f * (x * y + z * w);
    R.m[1][1] = 1.0f - 2.0f * (x * x + z * z);
    R.m[1][2] = 2.0f * (y * z - x * w);
    R.m[2][0] = 2.0f * (x * z - y * w);
    R.m[2][1] = 2.0f * (y * z + x * w);
    R.m[2][2] = 1.0f - 2.0f * (x * x + y * y);
    return R;
}

inline void mul_vec(const Mat3& R, float x, float y, float z, float& ox, float& oy, float& oz) {
    ox = R.m[0][0] * x + R.m[0][1] * y + R.m[0][2] * z;
    oy = R.m[1][0] * x + R.m[1][1] * y + R.m[1][2] * z;
    oz = R.m[2][0] * x + R.m[2][1] * y + R.m[2][2] * z;
}

float read_f32(const uint8_t* p, bool big_endian) {
    uint32_t u = 0;
    std::memcpy(&u, p, sizeof(uint32_t));
    if (big_endian) {
        u = ((u & 0x000000FFU) << 24) | ((u & 0x0000FF00U) << 8) | ((u & 0x00FF0000U) >> 8) |
            ((u & 0xFF000000U) >> 24);
    }
    float f = 0.0f;
    std::memcpy(&f, &u, sizeof(float));
    return f;
}

struct BridgeState {
    explicit BridgeState(const Config& cfg_)
        : cfg(cfg_),
          nx(static_cast<int>(std::floor(cfg.size_x / cfg.resolution + 1.0e-9)) + 1),
          ny(static_cast<int>(std::floor(cfg.size_y / cfg.resolution + 1.0e-9)) + 1),
          dim(nx * ny),
          x0(-0.5 * cfg.size_x),
          y0(-0.5 * cfg.size_y) {
        height_scan.assign(static_cast<size_t>(dim), 0.0f);
        top_z.assign(static_cast<size_t>(dim), -std::numeric_limits<float>::infinity());

        const float rr = static_cast<float>(cfg.lidar_rpy_deg[0] * M_PI / 180.0);
        const float rp = static_cast<float>(cfg.lidar_rpy_deg[1] * M_PI / 180.0);
        const float ry = static_cast<float>(cfg.lidar_rpy_deg[2] * M_PI / 180.0);
        r_lidar_to_base = rpy_to_rot(rr, rp, ry);
        t_lidar_to_base[0] = static_cast<float>(cfg.lidar_pos[0]);
        t_lidar_to_base[1] = static_cast<float>(cfg.lidar_pos[1]);
        t_lidar_to_base[2] = static_cast<float>(cfg.lidar_pos[2]);
    }

    Config cfg;
    int nx;
    int ny;
    int dim;
    double x0;
    double y0;

    Mat3 r_lidar_to_base{};
    float t_lidar_to_base[3]{};

    std::mutex imu_mtx;
    bool has_imu = false;
    float q_wxyz[4]{1.0f, 0.0f, 0.0f, 0.0f};

    int sock_fd = -1;
    sockaddr_in udp_addr{};

    std::vector<float> height_scan;
    std::vector<float> top_z;

    std::atomic<uint64_t> seq{0};
    std::atomic<uint64_t> points_last{0};
    std::atomic<uint64_t> hits_last{0};
    std::atomic<uint64_t> dropped_last{0};
    std::atomic<float> h_min_last{0.0f};
    std::atomic<float> h_mean_last{0.0f};
    std::atomic<float> h_max_last{0.0f};
    std::atomic<bool> cloud_info_printed{false};

    std::chrono::steady_clock::time_point last_send{};
    std::chrono::steady_clock::time_point last_stats{};
};

bool setup_udp(BridgeState& st) {
    st.sock_fd = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (st.sock_fd < 0) {
        std::cerr << "[dds_height_bridge] failed to create UDP socket\n";
        return false;
    }
    st.udp_addr = {};
    st.udp_addr.sin_family = AF_INET;
    st.udp_addr.sin_port = htons(static_cast<uint16_t>(st.cfg.udp_port));
    if (::inet_pton(AF_INET, st.cfg.udp_host.c_str(), &st.udp_addr.sin_addr) != 1) {
        std::cerr << "[dds_height_bridge] invalid UDP host: " << st.cfg.udp_host << "\n";
        return false;
    }
    return true;
}

void on_lowstate(BridgeState& st, const LowStateMsg& msg) {
    std::lock_guard<std::mutex> lock(st.imu_mtx);
    const auto& q = msg.imu_state().quaternion();
    st.q_wxyz[0] = q[0];
    st.q_wxyz[1] = q[1];
    st.q_wxyz[2] = q[2];
    st.q_wxyz[3] = q[3];
    st.has_imu = true;
}

void on_pointcloud(BridgeState& st, const PointCloudMsg& msg) {
    const auto now = std::chrono::steady_clock::now();
    const double min_dt = 1.0 / st.cfg.publish_hz;
    if (st.last_send.time_since_epoch().count() != 0) {
        const double dt = std::chrono::duration_cast<std::chrono::duration<double>>(now - st.last_send).count();
        if (dt < min_dt) {
            return;
        }
    }

    int x_off = -1;
    int y_off = -1;
    int z_off = -1;
    for (const auto& f : msg.fields()) {
        if (f.datatype() != sensor_msgs::msg::dds_::PointField_Constants::FLOAT32_) {
            continue;
        }
        if (f.name() == "x") {
            x_off = static_cast<int>(f.offset());
        } else if (f.name() == "y") {
            y_off = static_cast<int>(f.offset());
        } else if (f.name() == "z") {
            z_off = static_cast<int>(f.offset());
        }
    }
    if (x_off < 0 || y_off < 0 || z_off < 0) {
        return;
    }

    if (!st.cloud_info_printed.exchange(true, std::memory_order_relaxed)) {
        std::cout << "[dds_height_bridge] cloud frame_id=" << msg.header().frame_id()
                  << ", width=" << msg.width() << ", height=" << msg.height()
                  << ", point_step=" << msg.point_step() << "\n";
    }

    const uint32_t width = msg.width();
    const uint32_t height = msg.height();
    const uint32_t point_step = msg.point_step();
    const uint32_t row_step = msg.row_step();
    const bool big_endian = msg.is_bigendian();
    const auto& data = msg.data();

    if (point_step < 12 || width == 0 || height == 0) {
        return;
    }
    if (data.empty()) {
        return;
    }
    if (row_step < point_step * width) {
        return;
    }
    if (data.size() < static_cast<size_t>(row_step) * static_cast<size_t>(height)) {
        return;
    }

    Mat3 r_wb{};
    bool use_imu_now = false;
    if (st.cfg.use_imu) {
        std::lock_guard<std::mutex> lock(st.imu_mtx);
        use_imu_now = st.has_imu;
        if (use_imu_now) {
            r_wb = quat_wxyz_to_rot(st.q_wxyz[0], st.q_wxyz[1], st.q_wxyz[2], st.q_wxyz[3]);
        }
    }

    float yaw = 0.0f;
    float cy = 1.0f;
    float sy = 0.0f;
    if (use_imu_now) {
        yaw = std::atan2(r_wb.m[1][0], r_wb.m[0][0]);
        cy = std::cos(yaw);
        sy = std::sin(yaw);
    }

    std::fill(st.top_z.begin(), st.top_z.end(), -std::numeric_limits<float>::infinity());
    uint64_t n_points = 0;
    uint64_t n_hits = 0;
    uint64_t n_drop = 0;

    for (uint32_t r = 0; r < height; ++r) {
        const uint8_t* row_ptr = data.data() + static_cast<size_t>(r) * row_step;
        for (uint32_t c = 0; c < width; ++c) {
            const uint8_t* p = row_ptr + static_cast<size_t>(c) * point_step;

            const float lx = read_f32(p + x_off, big_endian);
            const float ly = read_f32(p + y_off, big_endian);
            const float lz = read_f32(p + z_off, big_endian);
            if (!std::isfinite(lx) || !std::isfinite(ly) || !std::isfinite(lz)) {
                ++n_drop;
                continue;
            }
            ++n_points;

            float bx = 0.0f, by = 0.0f, bz = 0.0f;
            mul_vec(st.r_lidar_to_base, lx, ly, lz, bx, by, bz);
            bx += st.t_lidar_to_base[0];
            by += st.t_lidar_to_base[1];
            bz += st.t_lidar_to_base[2];

            const double range = std::hypot(static_cast<double>(bx), static_cast<double>(by));
            if (range < st.cfg.min_range || range > st.cfg.max_range) {
                ++n_drop;
                continue;
            }

            float ax = bx, ay = by, z_metric = bz;
            if (use_imu_now) {
                float wx = 0.0f, wy = 0.0f, wz = 0.0f;
                mul_vec(r_wb, bx, by, bz, wx, wy, wz);
                z_metric = wz;
                ax = cy * wx + sy * wy;
                ay = -sy * wx + cy * wy;
            }

            if (z_metric < st.cfg.z_min || z_metric > st.cfg.z_max) {
                ++n_drop;
                continue;
            }

            const int ix = static_cast<int>(std::floor((ax - st.x0) / st.cfg.resolution + 1.0e-9));
            const int iy = static_cast<int>(std::floor((ay - st.y0) / st.cfg.resolution + 1.0e-9));
            if (ix < 0 || ix >= st.nx || iy < 0 || iy >= st.ny) {
                ++n_drop;
                continue;
            }

            const int idx = iy * st.nx + ix; // ordering=xy
            if (z_metric > st.top_z[static_cast<size_t>(idx)]) {
                st.top_z[static_cast<size_t>(idx)] = z_metric;
            }
        }
    }

    float h_min = std::numeric_limits<float>::infinity();
    float h_max = -std::numeric_limits<float>::infinity();
    double h_sum = 0.0;

    for (int i = 0; i < st.dim; ++i) {
        float h = st.cfg.hold_last_grid ? st.height_scan[static_cast<size_t>(i)] : 0.0f;
        if (std::isfinite(st.top_z[static_cast<size_t>(i)])) {
            h = -st.top_z[static_cast<size_t>(i)] - static_cast<float>(st.cfg.offset);
            ++n_hits;
        }
        if (h < st.cfg.clip_min) {
            h = st.cfg.clip_min;
        }
        if (h > st.cfg.clip_max) {
            h = st.cfg.clip_max;
        }
        st.height_scan[static_cast<size_t>(i)] = h;
        h_min = std::min(h_min, h);
        h_max = std::max(h_max, h);
        h_sum += static_cast<double>(h);
    }

    const ssize_t expected = static_cast<ssize_t>(st.height_scan.size() * sizeof(float));
    const ssize_t sent = ::sendto(
        st.sock_fd,
        reinterpret_cast<const char*>(st.height_scan.data()),
        static_cast<size_t>(expected),
        0,
        reinterpret_cast<const sockaddr*>(&st.udp_addr),
        sizeof(st.udp_addr));

    if (sent != expected) {
        std::cerr << "[dds_height_bridge] UDP send mismatch: sent=" << sent << " expected=" << expected << "\n";
    }

    st.last_send = now;
    st.seq.fetch_add(1, std::memory_order_relaxed);
    st.points_last.store(n_points, std::memory_order_relaxed);
    st.hits_last.store(n_hits, std::memory_order_relaxed);
    st.dropped_last.store(n_drop, std::memory_order_relaxed);
    st.h_min_last.store(h_min, std::memory_order_relaxed);
    st.h_max_last.store(h_max, std::memory_order_relaxed);
    st.h_mean_last.store(static_cast<float>(h_sum / static_cast<double>(st.dim)), std::memory_order_relaxed);

    if (st.last_stats.time_since_epoch().count() == 0) {
        st.last_stats = now;
    } else {
        const double dt_stats =
            std::chrono::duration_cast<std::chrono::duration<double>>(now - st.last_stats).count();
        if (dt_stats >= st.cfg.stats_interval) {
            st.last_stats = now;
            std::cout << "[dds_height_bridge] seq=" << st.seq.load() << " topic=" << st.cfg.topic
                      << " points=" << st.points_last.load() << " hits=" << st.hits_last.load() << "/" << st.dim
                      << " drop=" << st.dropped_last.load() << " udp=" << st.cfg.udp_host << ":" << st.cfg.udp_port
                      << " imu=" << (use_imu_now ? "on" : "off")
                      << " h[min/mean/max]=" << std::fixed << std::setprecision(3)
                      << st.h_min_last.load() << "/" << st.h_mean_last.load() << "/" << st.h_max_last.load()
                      << "\n";
        }
    }
}

} // namespace

int main(int argc, char** argv) {
    Config cfg;
    parse_args(argc, argv, cfg);

    BridgeState st(cfg);
    if (!setup_udp(st)) {
        return 1;
    }

    std::cout << " --- Unitree Go2 DDS Height-Scan Bridge ---\n";
    std::cout << "network=" << (cfg.network.empty() ? "<default>" : cfg.network) << "\n";
    std::cout << "pc_topic=" << cfg.topic << ", lowstate_topic=" << cfg.lowstate_topic << "\n";
    std::cout << "udp=" << cfg.udp_host << ":" << cfg.udp_port << ", dim=" << st.dim << " (" << st.nx << "x" << st.ny
              << ")\n";
    std::cout << "grid=(" << cfg.size_x << "," << cfg.size_y << "), res=" << cfg.resolution
              << ", offset=" << cfg.offset << ", clip=[" << cfg.clip_min << "," << cfg.clip_max << "]\n";
    std::cout << "lidar_pos=(" << cfg.lidar_pos[0] << "," << cfg.lidar_pos[1] << "," << cfg.lidar_pos[2]
              << "), lidar_rpy_deg=(" << cfg.lidar_rpy_deg[0] << "," << cfg.lidar_rpy_deg[1] << ","
              << cfg.lidar_rpy_deg[2] << "), use_imu=" << (cfg.use_imu ? "1" : "0")
              << ", hold_last_grid=" << (cfg.hold_last_grid ? "1" : "0") << "\n";

    unitree::robot::ChannelFactory::Instance()->Init(0, cfg.network);

    auto low_sub = std::make_shared<unitree::robot::ChannelSubscriber<LowStateMsg>>(cfg.lowstate_topic);
    low_sub->InitChannel([&st](const void* msg_void) {
        const auto* msg = reinterpret_cast<const LowStateMsg*>(msg_void);
        on_lowstate(st, *msg);
    });

    auto pc_sub = std::make_shared<unitree::robot::ChannelSubscriber<PointCloudMsg>>(cfg.topic);
    pc_sub->InitChannel([&st](const void* msg_void) {
        const auto* msg = reinterpret_cast<const PointCloudMsg*>(msg_void);
        on_pointcloud(st, *msg);
    });

    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    return 0;
}
