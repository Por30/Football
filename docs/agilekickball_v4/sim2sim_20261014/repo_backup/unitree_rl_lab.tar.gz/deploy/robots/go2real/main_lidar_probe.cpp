#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#include <unitree/idl/go2/HeightMap_.hpp>
#include <unitree/idl/go2/LidarState_.hpp>
#include <unitree/idl/go2/LowState_.hpp>
#include <unitree/idl/ros2/PointCloud2_.hpp>
#include <unitree/robot/channel/channel_factory.hpp>
#include <unitree/robot/channel/channel_subscriber.hpp>

namespace {

using PointCloudMsg = sensor_msgs::msg::dds_::PointCloud2_;
using LidarStateMsg = unitree_go::msg::dds_::LidarState_;
using HeightMapMsg = unitree_go::msg::dds_::HeightMap_;
using LowStateMsg = unitree_go::msg::dds_::LowState_;

struct ProbePC {
    explicit ProbePC(std::string t) : topic(std::move(t)) {}
    std::string topic;
    std::atomic<uint64_t> count{0};
    std::atomic<uint32_t> width{0};
    std::atomic<uint32_t> height{0};
    std::atomic<uint32_t> point_step{0};
    std::atomic<uint32_t> row_step{0};
    std::atomic<uint32_t> data_size{0};
    std::shared_ptr<unitree::robot::ChannelSubscriber<PointCloudMsg>> sub;
};

struct ProbeLidarState {
    explicit ProbeLidarState(std::string t) : topic(std::move(t)) {}
    std::string topic;
    std::atomic<uint64_t> count{0};
    std::atomic<float> cloud_freq{0.0f};
    std::atomic<float> packet_loss{0.0f};
    std::atomic<uint32_t> cloud_size{0};
    std::shared_ptr<unitree::robot::ChannelSubscriber<LidarStateMsg>> sub;
};

struct ProbeHeightMap {
    explicit ProbeHeightMap(std::string t) : topic(std::move(t)) {}
    std::string topic;
    std::atomic<uint64_t> count{0};
    std::atomic<uint32_t> width{0};
    std::atomic<uint32_t> height{0};
    std::atomic<uint32_t> origin_size{0};
    std::atomic<uint32_t> data_size{0};
    std::shared_ptr<unitree::robot::ChannelSubscriber<HeightMapMsg>> sub;
};

struct ProbeLowState {
    explicit ProbeLowState(std::string t) : topic(std::move(t)) {}
    std::string topic;
    std::atomic<uint64_t> count{0};
    std::atomic<float> roll{0.0f};
    std::atomic<float> pitch{0.0f};
    std::atomic<float> yaw{0.0f};
    std::shared_ptr<unitree::robot::ChannelSubscriber<LowStateMsg>> sub;
};

bool starts_with(const std::string& s, const std::string& p) {
    return s.size() >= p.size() && s.compare(0, p.size(), p) == 0;
}

int parse_int(const char* s, int fallback) {
    if (!s) {
        return fallback;
    }
    char* end = nullptr;
    long v = std::strtol(s, &end, 10);
    if (!end || *end != '\0') {
        return fallback;
    }
    return static_cast<int>(v);
}

double parse_double(const char* s, double fallback) {
    if (!s) {
        return fallback;
    }
    char* end = nullptr;
    double v = std::strtod(s, &end);
    if (!end || *end != '\0') {
        return fallback;
    }
    return v;
}

void print_usage(const char* prog) {
    std::cout << "Usage: " << prog << " [--network <iface>] [--seconds <N>] [--period-ms <N>]\n";
}

} // namespace

int main(int argc, char** argv) {
    std::string network = "";
    double run_seconds = 8.0;
    int period_ms = 1000;

    for (int i = 1; i < argc; ++i) {
        const std::string arg(argv[i]);
        if (arg == "--help" || arg == "-h") {
            print_usage(argv[0]);
            return 0;
        }
        if ((arg == "--network" || arg == "-n") && i + 1 < argc) {
            network = argv[++i];
            continue;
        }
        if (starts_with(arg, "--network=")) {
            network = arg.substr(std::strlen("--network="));
            continue;
        }
        if (arg == "--seconds" && i + 1 < argc) {
            run_seconds = parse_double(argv[++i], run_seconds);
            continue;
        }
        if (starts_with(arg, "--seconds=")) {
            run_seconds = parse_double(arg.c_str() + std::strlen("--seconds="), run_seconds);
            continue;
        }
        if (arg == "--period-ms" && i + 1 < argc) {
            period_ms = parse_int(argv[++i], period_ms);
            continue;
        }
        if (starts_with(arg, "--period-ms=")) {
            period_ms = parse_int(arg.c_str() + std::strlen("--period-ms="), period_ms);
            continue;
        }
    }

    if (run_seconds < 1.0) {
        run_seconds = 1.0;
    }
    if (period_ms < 100) {
        period_ms = 100;
    }

    std::cout << " --- Unitree Go2 DDS Lidar Probe ---\n";
    std::cout << "network=" << (network.empty() ? "<default>" : network)
              << ", duration=" << run_seconds << "s, period=" << period_ms << "ms\n";

    unitree::robot::ChannelFactory::Instance()->Init(0, network);

    std::vector<std::unique_ptr<ProbePC>> pc_probes;
    for (const auto& t : {
             std::string("rt/utlidar/cloud"),
             std::string("rt/lidar/cloud"),
             std::string("rt/pointcloud"),
             std::string("rt/cloud"),
             std::string("/utlidar/cloud"),
             std::string("/lidar/points"),
         }) {
        pc_probes.emplace_back(std::make_unique<ProbePC>(t));
    }
    for (auto& p : pc_probes) {
        p->sub = std::make_shared<unitree::robot::ChannelSubscriber<PointCloudMsg>>(p->topic);
        p->sub->InitChannel([pp = p.get()](const void* msg_void) {
            const auto* msg = reinterpret_cast<const PointCloudMsg*>(msg_void);
            pp->count.fetch_add(1, std::memory_order_relaxed);
            pp->width.store(msg->width(), std::memory_order_relaxed);
            pp->height.store(msg->height(), std::memory_order_relaxed);
            pp->point_step.store(msg->point_step(), std::memory_order_relaxed);
            pp->row_step.store(msg->row_step(), std::memory_order_relaxed);
            pp->data_size.store(static_cast<uint32_t>(msg->data().size()), std::memory_order_relaxed);
        });
    }

    std::vector<std::unique_ptr<ProbeLidarState>> ls_probes;
    for (const auto& t : {
             std::string("rt/lidarstate"),
             std::string("rt/lidar/state"),
             std::string("rt/utlidar/state"),
         }) {
        ls_probes.emplace_back(std::make_unique<ProbeLidarState>(t));
    }
    for (auto& p : ls_probes) {
        p->sub = std::make_shared<unitree::robot::ChannelSubscriber<LidarStateMsg>>(p->topic);
        p->sub->InitChannel([pp = p.get()](const void* msg_void) {
            const auto* msg = reinterpret_cast<const LidarStateMsg*>(msg_void);
            pp->count.fetch_add(1, std::memory_order_relaxed);
            pp->cloud_freq.store(msg->cloud_frequency(), std::memory_order_relaxed);
            pp->packet_loss.store(msg->cloud_packet_loss_rate(), std::memory_order_relaxed);
            pp->cloud_size.store(msg->cloud_size(), std::memory_order_relaxed);
        });
    }

    std::vector<std::unique_ptr<ProbeHeightMap>> hm_probes;
    for (const auto& t : {
             std::string("rt/height_map"),
             std::string("rt/heightmap"),
             std::string("rt/utlidar/height_map"),
         }) {
        hm_probes.emplace_back(std::make_unique<ProbeHeightMap>(t));
    }
    for (auto& p : hm_probes) {
        p->sub = std::make_shared<unitree::robot::ChannelSubscriber<HeightMapMsg>>(p->topic);
        p->sub->InitChannel([pp = p.get()](const void* msg_void) {
            const auto* msg = reinterpret_cast<const HeightMapMsg*>(msg_void);
            pp->count.fetch_add(1, std::memory_order_relaxed);
            pp->width.store(msg->width(), std::memory_order_relaxed);
            pp->height.store(msg->height(), std::memory_order_relaxed);
            pp->origin_size.store(static_cast<uint32_t>(msg->origin().size()), std::memory_order_relaxed);
            pp->data_size.store(static_cast<uint32_t>(msg->data().size()), std::memory_order_relaxed);
        });
    }

    auto low_probe = std::make_unique<ProbeLowState>("rt/lowstate");
    low_probe->sub = std::make_shared<unitree::robot::ChannelSubscriber<LowStateMsg>>(low_probe->topic);
    low_probe->sub->InitChannel([pp = low_probe.get()](const void* msg_void) {
        const auto* msg = reinterpret_cast<const LowStateMsg*>(msg_void);
        pp->count.fetch_add(1, std::memory_order_relaxed);
        const auto& rpy = msg->imu_state().rpy();
        pp->roll.store(rpy[0], std::memory_order_relaxed);
        pp->pitch.store(rpy[1], std::memory_order_relaxed);
        pp->yaw.store(rpy[2], std::memory_order_relaxed);
    });

    const auto t0 = std::chrono::steady_clock::now();
    auto t_next = t0;
    while (true) {
        const auto now = std::chrono::steady_clock::now();
        const double elapsed = std::chrono::duration_cast<std::chrono::duration<double>>(now - t0).count();
        if (elapsed >= run_seconds) {
            break;
        }
        if (now >= t_next) {
            t_next = now + std::chrono::milliseconds(period_ms);
            std::cout << "\n[Probe t=" << std::fixed << std::setprecision(1) << elapsed << "s]\n";
            std::cout << "lowstate rt/lowstate: count=" << low_probe->count.load()
                      << " rpy=(" << low_probe->roll.load() << ", "
                      << low_probe->pitch.load() << ", " << low_probe->yaw.load() << ")\n";

            for (const auto& p : pc_probes) {
                std::cout << "pc " << p->topic << ": count=" << p->count.load();
                if (p->count.load() > 0) {
                    std::cout << " wh=(" << p->width.load() << "," << p->height.load() << ")"
                              << " step=(" << p->point_step.load() << "," << p->row_step.load() << ")"
                              << " bytes=" << p->data_size.load();
                }
                std::cout << "\n";
            }
            for (const auto& p : ls_probes) {
                std::cout << "lidar_state " << p->topic << ": count=" << p->count.load();
                if (p->count.load() > 0) {
                    std::cout << " freq=" << p->cloud_freq.load()
                              << " loss=" << p->packet_loss.load()
                              << " size=" << p->cloud_size.load();
                }
                std::cout << "\n";
            }
            for (const auto& p : hm_probes) {
                std::cout << "height_map " << p->topic << ": count=" << p->count.load();
                if (p->count.load() > 0) {
                    std::cout << " wh=(" << p->width.load() << "," << p->height.load() << ")"
                              << " origin=" << p->origin_size.load()
                              << " data=" << p->data_size.load();
                }
                std::cout << "\n";
            }
            std::cout.flush();
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }

    std::cout << "\n=== Summary ===\n";
    bool any_pc = false;
    for (const auto& p : pc_probes) {
        if (p->count.load() > 0) {
            any_pc = true;
            std::cout << "[OK] PointCloud topic active: " << p->topic << " count=" << p->count.load() << "\n";
        }
    }
    bool any_ls = false;
    for (const auto& p : ls_probes) {
        if (p->count.load() > 0) {
            any_ls = true;
            std::cout << "[OK] LidarState topic active: " << p->topic << " count=" << p->count.load() << "\n";
        }
    }
    bool any_hm = false;
    for (const auto& p : hm_probes) {
        if (p->count.load() > 0) {
            any_hm = true;
            std::cout << "[OK] HeightMap topic active: " << p->topic << " count=" << p->count.load() << "\n";
        }
    }

    if (!any_pc && !any_ls && !any_hm) {
        std::cout << "[WARN] No lidar-related DDS topic received in probe window.\n";
        std::cout << "       lowstate_count=" << low_probe->count.load()
                  << " (if >0, DDS network is OK but lidar service/topic may be off)\n";
        return 2;
    }

    return 0;
}
