#include "FSM/State_RLBase.h"
#include "height_scan_receiver.h"
#include "isaaclab/envs/mdp/actions/joint_actions.h"
#include "isaaclab/envs/mdp/observations/observations.h"
#include "unitree_articulation.h"

#include <mutex>

namespace isaaclab
{
namespace mdp
{

REGISTER_OBSERVATION(height_scan)
{
    const int dim = params["dim"] ? params["dim"].as<int>() : 160;
    const std::string bind_address = params["bind_address"] ? params["bind_address"].as<std::string>() : "0.0.0.0";
    const int port = params["port"] ? params["port"].as<int>() : 9876;
    const float timeout_s = params["timeout_s"] ? params["timeout_s"].as<float>() : 0.2f;
    const float default_value = params["default_value"] ? params["default_value"].as<float>() : 0.0f;
    const bool hold_last = params["hold_last_on_timeout"] ? params["hold_last_on_timeout"].as<bool>() : true;

    static std::mutex receiver_mtx;
    static std::unique_ptr<HeightScanReceiver> receiver;

    {
        std::lock_guard<std::mutex> guard(receiver_mtx);
        const bool need_recreate = (!receiver)
            || receiver->port() != port
            || receiver->expected_dim() != dim
            || receiver->bind_address() != bind_address;

        if (need_recreate) {
            try {
                receiver = std::make_unique<HeightScanReceiver>(bind_address, port, dim);
                spdlog::info("[height_scan] listening on udp://{}:{} (dim={})", bind_address, port, dim);
            } catch (const std::exception& e) {
                spdlog::error("[height_scan] receiver init failed: {}", e.what());
                return std::vector<float>(static_cast<std::size_t>(dim), default_value);
            }
        }
    }

    if (!receiver) {
        return std::vector<float>(static_cast<std::size_t>(dim), default_value);
    }

    bool fresh = false;
    auto obs = receiver->get_latest(static_cast<std::size_t>(dim), timeout_s, default_value, hold_last, &fresh);

    static std::size_t stale_warn_counter = 0;
    if (!fresh && ((stale_warn_counter++ % 500) == 0)) {
        spdlog::warn("[height_scan] stale/no packet, using {} values", hold_last ? "cached" : "default");
    }

    return obs;
}

} // namespace mdp
} // namespace isaaclab

State_RLBase::State_RLBase(int state_mode, std::string state_string)
: FSMState(state_mode, state_string)
{
    auto cfg = param::config["FSM"][state_string];
    auto policy_dir = param::parser_policy_dir(cfg["policy_dir"].as<std::string>());

    env = std::make_unique<isaaclab::ManagerBasedRLEnv>(
        YAML::LoadFile(policy_dir / "params" / "deploy.yaml"),
        std::make_shared<unitree::BaseArticulation<LowState_t::SharedPtr>>(FSMState::lowstate)
    );
    env->alg = std::make_unique<isaaclab::OrtRunner>(policy_dir / "exported" / "policy.onnx");

    this->registered_checks.emplace_back(
        std::make_pair(
            [&]()->bool{ return isaaclab::mdp::bad_orientation(env.get(), 1.0); },
            FSMStringMap.right.at("Passive")
        )
    );
}

void State_RLBase::run()
{
    auto action = env->action_manager->processed_actions();
    for (int i = 0; i < env->robot->data.joint_ids_map.size(); i++) {
        lowcmd->msg_.motor_cmd()[env->robot->data.joint_ids_map[i]].q() = action[i];
    }
}
