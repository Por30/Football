#include "height_scan_receiver.h"

#include <arpa/inet.h>
#include <cstring>
#include <errno.h>
#include <netinet/in.h>
#include <spdlog/spdlog.h>
#include <sstream>
#include <stdexcept>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

HeightScanReceiver::HeightScanReceiver(std::string bind_address, int port, int expected_dim)
    : bind_address_(std::move(bind_address)), port_(port), expected_dim_(expected_dim)
{
    if (expected_dim_ <= 0) {
        throw std::invalid_argument("height_scan expected_dim must be > 0");
    }

    sock_fd_ = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd_ < 0) {
        throw std::runtime_error("failed to create UDP socket");
    }

    int opt = 1;
    ::setsockopt(sock_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    timeval tv{};
    tv.tv_sec = 0;
    tv.tv_usec = 200 * 1000; // 200ms
    ::setsockopt(sock_fd_, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<uint16_t>(port_));
    if (::inet_pton(AF_INET, bind_address_.c_str(), &addr.sin_addr) <= 0) {
        ::close(sock_fd_);
        sock_fd_ = -1;
        throw std::runtime_error("invalid bind address: " + bind_address_);
    }

    if (::bind(sock_fd_, reinterpret_cast<const sockaddr*>(&addr), sizeof(addr)) < 0) {
        const std::string err = std::strerror(errno);
        ::close(sock_fd_);
        sock_fd_ = -1;
        throw std::runtime_error("failed to bind UDP socket: " + err);
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        latest_.assign(static_cast<std::size_t>(expected_dim_), 0.0f);
    }

    running_.store(true);
    thread_ = std::thread(&HeightScanReceiver::run_loop, this);
}

HeightScanReceiver::~HeightScanReceiver()
{
    running_.store(false);
    if (thread_.joinable()) {
        thread_.join();
    }
    if (sock_fd_ >= 0) {
        ::close(sock_fd_);
        sock_fd_ = -1;
    }
}

std::vector<float> HeightScanReceiver::get_latest(
    std::size_t dim,
    float timeout_s,
    float default_value,
    bool hold_last_on_timeout,
    bool* fresh)
{
    std::lock_guard<std::mutex> lock(mutex_);
    const auto now = std::chrono::steady_clock::now();

    bool is_fresh = false;
    if (has_data_) {
        const auto age = std::chrono::duration_cast<std::chrono::duration<float>>(now - last_update_).count();
        is_fresh = age <= timeout_s;
    }

    if (fresh != nullptr) {
        *fresh = is_fresh;
    }

    if (is_fresh || (hold_last_on_timeout && has_data_)) {
        std::vector<float> out = latest_;
        if (out.size() != dim) {
            out.resize(dim, default_value);
        }
        return out;
    }

    return std::vector<float>(dim, default_value);
}

std::vector<float> HeightScanReceiver::parse_packet(const char* data, std::size_t len) const
{
    // Format A: exact float32 binary payload (dim * 4 bytes)
    if (len == static_cast<std::size_t>(expected_dim_) * sizeof(float)) {
        std::vector<float> out(static_cast<std::size_t>(expected_dim_));
        std::memcpy(out.data(), data, len);
        return out;
    }

    // Format B: ASCII list, delimiters: comma/space/newline/tab/semicolon
    std::string text(data, data + len);
    for (char& ch : text) {
        if (ch == ',' || ch == ';' || ch == '\n' || ch == '\r' || ch == '\t') {
            ch = ' ';
        }
    }

    std::istringstream iss(text);
    std::vector<float> out;
    out.reserve(static_cast<std::size_t>(expected_dim_));
    float value = 0.0f;
    while (iss >> value) {
        out.push_back(value);
    }

    if (out.empty()) {
        return {};
    }

    if (out.size() < static_cast<std::size_t>(expected_dim_)) {
        out.resize(static_cast<std::size_t>(expected_dim_), 0.0f);
    } else if (out.size() > static_cast<std::size_t>(expected_dim_)) {
        out.resize(static_cast<std::size_t>(expected_dim_));
    }
    return out;
}

void HeightScanReceiver::run_loop()
{
    std::vector<char> buffer(static_cast<std::size_t>(expected_dim_) * sizeof(float) * 2 + 1024);
    while (running_.load()) {
        sockaddr_in src_addr{};
        socklen_t src_len = sizeof(src_addr);
        const ssize_t n = ::recvfrom(
            sock_fd_,
            buffer.data(),
            buffer.size(),
            0,
            reinterpret_cast<sockaddr*>(&src_addr),
            &src_len
        );

        if (n <= 0) {
            continue;
        }

        auto parsed = parse_packet(buffer.data(), static_cast<std::size_t>(n));
        if (parsed.empty()) {
            continue;
        }

        {
            std::lock_guard<std::mutex> lock(mutex_);
            latest_ = std::move(parsed);
            last_update_ = std::chrono::steady_clock::now();
            has_data_ = true;
        }
    }
}
