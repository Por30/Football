# Height-Scan LiDAR Bridge (Real Go2)

This bridge keeps the existing `go2real` controller unchanged and only provides
`height_scan` observation via UDP.

Recommended (no ROS dependency):

```
LiDAR + IMU (DDS) -> go2_lidar_height_bridge -> UDP:9876 -> go2real_ctrl
```

Legacy fallback:

```
LiDAR + IMU (ROS) -> height_scan_lidar_bridge.py -> UDP:9876 -> go2real_ctrl
```

## 1) Check real sensor topics

```bash
# DDS probe (recommended on go2real)
cd deploy/robots/go2real/build
./go2_lidar_probe --network eno1 --seconds 2 --period-ms 500
```

If DDS probe shows `topic=rt/utlidar/cloud` with increasing counts, use DDS bridge.
Use ROS bridge only if your point cloud is already published into ROS topics.

## 2) Start bridge

DDS bridge:

```bash
cd deploy/robots/go2real/build
./go2_lidar_height_bridge \
  --network eno1 \
  --topic rt/utlidar/cloud \
  --lowstate-topic rt/lowstate \
  --udp-host 127.0.0.1 \
  --udp-port 9876 \
  --publish-hz 50
```

Optional official switch (same idea as unitree_sdk2_python `go2_utlidar_switch.py`):

```bash
cd deploy/robots/go2real
python3 tools/utlidar_switch.py --network eno1 --state ON
```

ROS bridge (legacy):

```bash
cd deploy/robots/go2real
python3 tools/height_scan_lidar_bridge.py \
  --ros-version auto \
  --pointcloud-topic /utlidar/cloud \
  --imu-topic /trunk_imu \
  --udp-host 127.0.0.1 \
  --udp-port 9876 \
  --udp-hz 50
```

## 3) Start controller

```bash
cd deploy/robots/go2real/build
./go2real_ctrl --network eno1
```

Or one command:

```bash
cd deploy/robots/go2real
./tools/run_go2real_with_lidar.sh eno1
```

By default the script publishes `ON` to `rt/utlidar/switch` once before starting bridge.
To skip this step:

```bash
UTLIDAR_SWITCH=SKIP ./tools/run_go2real_with_lidar.sh eno1
```

Pass extra bridge args after network interface.

DDS example:

```bash
BRIDGE_MODE=dds DDS_PC_TOPIC=rt/utlidar/cloud ./tools/run_go2real_with_lidar.sh eno1
```

ROS example:

```bash
BRIDGE_MODE=ros PC_TOPIC=/points IMU_TOPIC=/trunk_imu ./tools/run_go2real_with_lidar.sh eno1 --lidar-rpy-deg 0 0 180
```

## Important parameters

- `--lidar-pos X Y Z` and `--lidar-rpy-deg R P Y`:
  static extrinsic from LiDAR frame to robot base frame.
- `--use-imu 1|0`:
  with IMU, bridge removes roll/pitch to match IsaacLab `ray_alignment="yaw"`.
- `--size-x --size-y --resolution`:
  keep `1.6 1.0 0.1` for your current policy (187 dims).
- `--offset`:
  keep `0.5` to match IsaacLab `height_scan`.
- `--clip-min --clip-max`:
  keep `-1 1` to match deploy config.

Default frame conversion in DDS bridge:
- Unitree `utlidar_lidar` is treated as FRD and converted to FLU by default (`--lidar-rpy-deg 180 0 0`).
- If you already pre-converted point cloud, override with `--lidar-rpy-deg 0 0 0`.

## Output definition (aligned with IsaacLab)

- Grid: `size=(1.6, 1.0)`, `resolution=0.1` -> `17 x 11 = 187`
- Ordering: `xy` (outer `y`, inner `x`)
- Height: `h = base_z - hit_z - offset`
- Clip: `[-1, 1]`
- UDP payload: little-endian float32 array (`187 * 4 = 748 bytes`)
