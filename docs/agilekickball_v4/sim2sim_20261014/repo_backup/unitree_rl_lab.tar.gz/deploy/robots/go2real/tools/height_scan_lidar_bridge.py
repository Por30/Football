#!/usr/bin/env python3
"""Bridge real LiDAR point cloud to IsaacLab-compatible height_scan UDP stream.

This script keeps the existing go2real deploy pipeline unchanged:
  LiDAR/IMU (ROS) -> height_scan (187 floats) -> UDP -> go2real controller

The output follows IsaacLab height-scan convention for Go2:
  - Grid: size=(1.6, 1.0), resolution=0.1 -> 17 x 11 = 187
  - Ordering: "xy" (outer y, inner x)
  - Height: h = base_z - hit_z - offset
  - Clip: [-1, 1]
  - ray_alignment="yaw" equivalent by removing roll/pitch using IMU orientation
"""

from __future__ import annotations

import argparse
import math
import os
import socket
import threading
import time
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np


def _rpy_to_rot(roll: float, pitch: float, yaw: float) -> np.ndarray:
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    # ZYX (yaw, pitch, roll)
    return np.array(
        [
            [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
            [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
            [-sp, cp * sr, cp * cr],
        ],
        dtype=np.float32,
    )


def _quat_wxyz_to_rot(q: np.ndarray) -> np.ndarray:
    w, x, y, z = q.astype(np.float64)
    n = math.sqrt(w * w + x * x + y * y + z * z)
    if n < 1e-9:
        return np.eye(3, dtype=np.float32)
    w, x, y, z = w / n, x / n, y / n, z / n
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float32,
    )


def _yaw_rot_inv(yaw: float) -> np.ndarray:
    cy, sy = math.cos(yaw), math.sin(yaw)
    # R_yaw^T
    return np.array(
        [[cy, sy, 0.0], [-sy, cy, 0.0], [0.0, 0.0, 1.0]],
        dtype=np.float32,
    )


def _pointcloud2_to_xyz(msg) -> np.ndarray:
    """Parse PointCloud2 into Nx3 float32 array without extra ROS helper deps."""
    if not msg.data:
        return np.empty((0, 3), dtype=np.float32)

    fields = {f.name: f for f in msg.fields}
    for name in ("x", "y", "z"):
        if name not in fields:
            raise RuntimeError(f"PointCloud2 missing field '{name}'.")

    # PointField.FLOAT32 == 7 in both ROS1 and ROS2
    for name in ("x", "y", "z"):
        if int(fields[name].datatype) != 7:
            raise RuntimeError(
                f"PointCloud2 field '{name}' must be float32 (datatype=7), got {fields[name].datatype}."
            )

    x_off = int(fields["x"].offset)
    y_off = int(fields["y"].offset)
    z_off = int(fields["z"].offset)
    point_step = int(msg.point_step)
    width = int(msg.width)
    height = int(msg.height)
    n_total = width * height
    if n_total <= 0:
        return np.empty((0, 3), dtype=np.float32)

    endian = ">" if bool(msg.is_bigendian) else "<"
    dtype = np.dtype(
        {
            "names": ["x", "y", "z"],
            "formats": [f"{endian}f4", f"{endian}f4", f"{endian}f4"],
            "offsets": [x_off, y_off, z_off],
            "itemsize": point_step,
        }
    )

    data_mv = memoryview(msg.data)
    if int(msg.row_step) == point_step * width:
        arr = np.ndarray(shape=(n_total,), dtype=dtype, buffer=data_mv)
        xyz = np.stack([arr["x"], arr["y"], arr["z"]], axis=1)
    else:
        rows = []
        row_bytes = point_step * width
        for r in range(height):
            s = r * int(msg.row_step)
            e = s + row_bytes
            row_arr = np.ndarray(shape=(width,), dtype=dtype, buffer=data_mv[s:e])
            rows.append(np.stack([row_arr["x"], row_arr["y"], row_arr["z"]], axis=1))
        xyz = np.concatenate(rows, axis=0) if rows else np.empty((0, 3), dtype=np.float32)

    valid = np.isfinite(xyz).all(axis=1)
    return xyz[valid].astype(np.float32, copy=False)


@dataclass
class HeightScanConfig:
    size_x: float
    size_y: float
    resolution: float
    offset: float
    clip_min: float
    clip_max: float
    ordering: str
    fill_empty: float
    min_range: float
    max_range: float
    z_min: float
    z_max: float
    max_points: int


class HeightScanBridge:
    def __init__(
        self,
        cfg: HeightScanConfig,
        udp_host: str,
        udp_port: int,
        udp_hz: float,
        lidar_pos: np.ndarray,
        lidar_rpy_rad: np.ndarray,
        use_imu: bool,
        stats_interval: float,
    ):
        self.cfg = cfg
        self.udp_hz = max(1.0, float(udp_hz))
        self.send_dt = 1.0 / self.udp_hz
        self.use_imu = use_imu
        self.stats_interval = max(0.2, float(stats_interval))

        self.nx = int(math.floor(cfg.size_x / cfg.resolution + 1.0e-9)) + 1
        self.ny = int(math.floor(cfg.size_y / cfg.resolution + 1.0e-9)) + 1
        self.dim = self.nx * self.ny
        self.x0 = -0.5 * cfg.size_x
        self.y0 = -0.5 * cfg.size_y

        self.r_lidar_to_base = _rpy_to_rot(float(lidar_rpy_rad[0]), float(lidar_rpy_rad[1]), float(lidar_rpy_rad[2]))
        self.t_lidar_to_base = lidar_pos.astype(np.float32)

        self._imu_lock = threading.Lock()
        self._q_wb: Optional[np.ndarray] = None

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._udp_addr = (udp_host, int(udp_port))
        self._last_send = 0.0
        self._last_stat = 0.0
        self._seq = 0
        self._points_last = 0
        self._hits_last = 0

    def update_imu(self, w: float, x: float, y: float, z: float):
        q = np.array([w, x, y, z], dtype=np.float32)
        with self._imu_lock:
            self._q_wb = q

    def _get_q_wb(self) -> Optional[np.ndarray]:
        with self._imu_lock:
            if self._q_wb is None:
                return None
            return self._q_wb.copy()

    def _downsample(self, pts: np.ndarray) -> np.ndarray:
        n = pts.shape[0]
        if self.cfg.max_points <= 0 or n <= self.cfg.max_points:
            return pts
        stride = int(math.ceil(n / float(self.cfg.max_points)))
        return pts[::stride][: self.cfg.max_points]

    def _build_height_scan(self, pts_lidar: np.ndarray) -> Tuple[np.ndarray, int]:
        if pts_lidar.size == 0:
            out = np.full((self.dim,), self.cfg.fill_empty, dtype=np.float32)
            return out, 0

        pts_lidar = self._downsample(pts_lidar)
        # lidar -> base
        pts_base = (pts_lidar @ self.r_lidar_to_base.T) + self.t_lidar_to_base

        # yaw-aligned frame and world-z equivalent
        if self.use_imu:
            q = self._get_q_wb()
        else:
            q = None

        if q is not None:
            r_wb = _quat_wxyz_to_rot(q)
            pts_w = pts_base @ r_wb.T
            yaw = math.atan2(float(r_wb[1, 0]), float(r_wb[0, 0]))
            r_yaw_inv = _yaw_rot_inv(yaw)
            pts_yaw = pts_w @ r_yaw_inv.T
            z_metric = pts_w[:, 2]
        else:
            pts_yaw = pts_base
            z_metric = pts_base[:, 2]

        x = pts_yaw[:, 0]
        y = pts_yaw[:, 1]
        r = np.hypot(x, y)
        valid = (
            np.isfinite(x)
            & np.isfinite(y)
            & np.isfinite(z_metric)
            & (r >= self.cfg.min_range)
            & (r <= self.cfg.max_range)
            & (z_metric >= self.cfg.z_min)
            & (z_metric <= self.cfg.z_max)
        )
        if not np.any(valid):
            out = np.full((self.dim,), self.cfg.fill_empty, dtype=np.float32)
            return out, 0

        x = x[valid]
        y = y[valid]
        z_metric = z_metric[valid].astype(np.float32, copy=False)

        ix = np.floor((x - self.x0) / self.cfg.resolution + 1.0e-9).astype(np.int32)
        iy = np.floor((y - self.y0) / self.cfg.resolution + 1.0e-9).astype(np.int32)
        inside = (ix >= 0) & (ix < self.nx) & (iy >= 0) & (iy < self.ny)
        if not np.any(inside):
            out = np.full((self.dim,), self.cfg.fill_empty, dtype=np.float32)
            return out, 0

        ix = ix[inside]
        iy = iy[inside]
        z_metric = z_metric[inside]

        if self.cfg.ordering == "xy":
            lin = iy * self.nx + ix
        else:
            lin = ix * self.ny + iy

        top_z = np.full((self.dim,), -np.inf, dtype=np.float32)
        np.maximum.at(top_z, lin, z_metric)

        out = np.full((self.dim,), self.cfg.fill_empty, dtype=np.float32)
        hit = np.isfinite(top_z)
        out[hit] = -top_z[hit] - self.cfg.offset
        np.clip(out, self.cfg.clip_min, self.cfg.clip_max, out=out)

        return out, int(np.count_nonzero(hit))

    def on_pointcloud(self, pts_lidar: np.ndarray):
        now = time.monotonic()
        if now - self._last_send < self.send_dt:
            return

        out, hit_cells = self._build_height_scan(pts_lidar)
        payload = out.astype("<f4", copy=False).tobytes()
        self._sock.sendto(payload, self._udp_addr)

        self._last_send = now
        self._seq += 1
        self._points_last = int(pts_lidar.shape[0])
        self._hits_last = hit_cells

        if now - self._last_stat >= self.stats_interval:
            self._last_stat = now
            print(
                f"[height_scan_bridge] seq={self._seq} pts={self._points_last} "
                f"hits={self._hits_last}/{self.dim} udp={self._udp_addr[0]}:{self._udp_addr[1]}"
            )


def _run_ros1(args, bridge: HeightScanBridge):
    import rospy
    from sensor_msgs.msg import Imu, PointCloud2

    rospy.init_node("height_scan_lidar_bridge", anonymous=False)

    def on_pc(msg: PointCloud2):
        try:
            pts = _pointcloud2_to_xyz(msg)
            bridge.on_pointcloud(pts)
        except Exception as exc:
            rospy.logwarn_throttle(1.0, f"point cloud parse failed: {exc}")

    def on_imu(msg: Imu):
        bridge.update_imu(
            msg.orientation.w,
            msg.orientation.x,
            msg.orientation.y,
            msg.orientation.z,
        )

    rospy.Subscriber(
        args.pointcloud_topic,
        PointCloud2,
        on_pc,
        queue_size=1,
        buff_size=2**24,
        tcp_nodelay=True,
    )
    if args.use_imu:
        rospy.Subscriber(args.imu_topic, Imu, on_imu, queue_size=5)

    rospy.loginfo(
        f"height_scan bridge ROS1 started. pc_topic={args.pointcloud_topic}, "
        f"imu_topic={args.imu_topic if args.use_imu else 'disabled'}"
    )
    rospy.spin()


def _run_ros2(args, bridge: HeightScanBridge):
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import Imu, PointCloud2

    class BridgeNode(Node):
        def __init__(self):
            super().__init__("height_scan_lidar_bridge")
            self.create_subscription(PointCloud2, args.pointcloud_topic, self._on_pc, 10)
            if args.use_imu:
                self.create_subscription(Imu, args.imu_topic, self._on_imu, 20)
            self.get_logger().info(
                f"height_scan bridge ROS2 started. pc_topic={args.pointcloud_topic}, "
                f"imu_topic={args.imu_topic if args.use_imu else 'disabled'}"
            )

        def _on_pc(self, msg: PointCloud2):
            try:
                pts = _pointcloud2_to_xyz(msg)
                bridge.on_pointcloud(pts)
            except Exception as exc:
                self.get_logger().warning(f"point cloud parse failed: {exc}")

        def _on_imu(self, msg: Imu):
            bridge.update_imu(
                msg.orientation.w,
                msg.orientation.x,
                msg.orientation.y,
                msg.orientation.z,
            )

    rclpy.init(args=None)
    node = BridgeNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


def _detect_ros_version(requested: str) -> str:
    if requested in ("1", "2"):
        return requested

    env_ros_version = os.environ.get("ROS_VERSION", "").strip()
    if env_ros_version in ("1", "2"):
        return env_ros_version

    try:
        import rclpy  # noqa: F401

        return "2"
    except Exception:
        pass

    try:
        import rospy  # noqa: F401

        return "1"
    except Exception:
        pass

    raise RuntimeError("Cannot detect ROS version. Set --ros-version {1|2}.")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Bridge LiDAR point cloud to IsaacLab-compatible height_scan UDP for go2real."
    )
    parser.add_argument("--ros-version", choices=["auto", "1", "2"], default="auto")
    parser.add_argument("--pointcloud-topic", type=str, default="/utlidar/cloud")
    parser.add_argument("--imu-topic", type=str, default="/trunk_imu")
    parser.add_argument("--use-imu", dest="use_imu", action="store_true", default=True)
    parser.add_argument("--no-use-imu", dest="use_imu", action="store_false")

    parser.add_argument("--udp-host", type=str, default="127.0.0.1")
    parser.add_argument("--udp-port", type=int, default=9876)
    parser.add_argument("--udp-hz", type=float, default=50.0)

    parser.add_argument("--size-x", type=float, default=1.6)
    parser.add_argument("--size-y", type=float, default=1.0)
    parser.add_argument("--resolution", type=float, default=0.1)
    parser.add_argument("--offset", type=float, default=0.5)
    parser.add_argument("--clip-min", type=float, default=-1.0)
    parser.add_argument("--clip-max", type=float, default=1.0)
    parser.add_argument("--ordering", choices=["xy", "yx"], default="xy")
    parser.add_argument("--fill-empty", type=float, default=0.0)

    parser.add_argument("--min-range", type=float, default=0.05)
    parser.add_argument("--max-range", type=float, default=3.0)
    parser.add_argument("--z-min", type=float, default=-2.0)
    parser.add_argument("--z-max", type=float, default=1.0)
    parser.add_argument("--max-points", type=int, default=25000)

    parser.add_argument("--lidar-pos", type=float, nargs=3, default=[0.0, 0.0, 0.0], metavar=("X", "Y", "Z"))
    parser.add_argument(
        "--lidar-rpy-deg",
        type=float,
        nargs=3,
        default=[0.0, 0.0, 0.0],
        metavar=("ROLL", "PITCH", "YAW"),
        help="Static extrinsic from lidar frame to base frame, degrees.",
    )

    parser.add_argument("--stats-interval", type=float, default=1.0)
    return parser.parse_args()


def main():
    args = parse_args()
    ros_version = _detect_ros_version(args.ros_version)

    lidar_pos = np.array(args.lidar_pos, dtype=np.float32)
    lidar_rpy_rad = np.deg2rad(np.array(args.lidar_rpy_deg, dtype=np.float32))

    cfg = HeightScanConfig(
        size_x=float(args.size_x),
        size_y=float(args.size_y),
        resolution=float(args.resolution),
        offset=float(args.offset),
        clip_min=float(args.clip_min),
        clip_max=float(args.clip_max),
        ordering=str(args.ordering),
        fill_empty=float(args.fill_empty),
        min_range=float(args.min_range),
        max_range=float(args.max_range),
        z_min=float(args.z_min),
        z_max=float(args.z_max),
        max_points=int(args.max_points),
    )

    bridge = HeightScanBridge(
        cfg=cfg,
        udp_host=args.udp_host,
        udp_port=args.udp_port,
        udp_hz=args.udp_hz,
        lidar_pos=lidar_pos,
        lidar_rpy_rad=lidar_rpy_rad,
        use_imu=bool(args.use_imu),
        stats_interval=args.stats_interval,
    )

    print(
        f"[height_scan_bridge] ros={ros_version}, topic={args.pointcloud_topic}, "
        f"imu={args.imu_topic if args.use_imu else 'disabled'}, "
        f"udp={args.udp_host}:{args.udp_port}, dim={bridge.dim} ({bridge.nx}x{bridge.ny})"
    )

    if ros_version == "1":
        _run_ros1(args, bridge)
    else:
        _run_ros2(args, bridge)


if __name__ == "__main__":
    main()
