#!/usr/bin/env python3
import argparse
import socket
import struct
import time
import math
import random


def build_wave(dim: int, t: float):
    vals = []
    for i in range(dim):
        x = i / max(1, dim - 1)
        v = 0.15 * math.sin(2.0 * math.pi * (x + 0.2 * t))
        v += 0.02 * (random.random() - 0.5)
        vals.append(v)
    return vals


def main():
    parser = argparse.ArgumentParser(description="Send height_scan UDP packets for go2real deploy testing")
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=9876)
    parser.add_argument("--dim", type=int, default=187)
    parser.add_argument("--hz", type=float, default=30.0)
    parser.add_argument("--format", choices=["binary", "ascii"], default="binary")
    args = parser.parse_args()

    dt = 1.0 / max(args.hz, 1e-3)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    print(f"Sending height_scan to udp://{args.host}:{args.port}, dim={args.dim}, hz={args.hz}, format={args.format}")

    t0 = time.time()
    while True:
        t = time.time() - t0
        vals = build_wave(args.dim, t)
        if args.format == "binary":
            payload = struct.pack("<" + "f" * len(vals), *vals)
        else:
            payload = (",".join(f"{v:.6f}" for v in vals)).encode("utf-8")
        sock.sendto(payload, (args.host, args.port))
        time.sleep(dt)


if __name__ == "__main__":
    main()
