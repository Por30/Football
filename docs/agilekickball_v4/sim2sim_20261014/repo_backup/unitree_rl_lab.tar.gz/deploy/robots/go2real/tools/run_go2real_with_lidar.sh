#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build"

NETWORK_IF="${1:-eth0}"
if [[ $# -gt 0 ]]; then
  shift
fi

BRIDGE_MODE="${BRIDGE_MODE:-dds}"  # dds | ros

# DDS defaults
DDS_PC_TOPIC="${DDS_PC_TOPIC:-rt/utlidar/cloud}"
DDS_LOWSTATE_TOPIC="${DDS_LOWSTATE_TOPIC:-rt/lowstate}"
UTLIDAR_SWITCH="${UTLIDAR_SWITCH:-ON}"   # ON | OFF | SKIP

# ROS defaults (legacy path)
PC_TOPIC="${PC_TOPIC:-/utlidar/cloud}"
IMU_TOPIC="${IMU_TOPIC:-/trunk_imu}"

UDP_HOST="${UDP_HOST:-127.0.0.1}"
UDP_PORT="${UDP_PORT:-9876}"

if [[ "${BRIDGE_MODE}" == "dds" ]]; then
  if [[ "${UTLIDAR_SWITCH}" == "ON" || "${UTLIDAR_SWITCH}" == "OFF" ]]; then
    if [[ -x "${ROOT_DIR}/tools/utlidar_switch.py" ]]; then
      echo "[run_go2real_with_lidar] publishing utlidar switch=${UTLIDAR_SWITCH} ..."
      python3 "${ROOT_DIR}/tools/utlidar_switch.py" \
        --network "${NETWORK_IF}" \
        --state "${UTLIDAR_SWITCH}" || true
      sleep 0.2
    fi
  fi

  if [[ ! -x "${BUILD_DIR}/go2_lidar_height_bridge" ]]; then
    echo "[run_go2real_with_lidar] missing ${BUILD_DIR}/go2_lidar_height_bridge, build first."
    exit 1
  fi
  echo "[run_go2real_with_lidar] starting DDS height_scan bridge..."
  "${BUILD_DIR}/go2_lidar_height_bridge" \
    --network "${NETWORK_IF}" \
    --topic "${DDS_PC_TOPIC}" \
    --lowstate-topic "${DDS_LOWSTATE_TOPIC}" \
    --udp-host "${UDP_HOST}" \
    --udp-port "${UDP_PORT}" \
    --publish-hz 50 \
    "$@" &
  sleep "${BRIDGE_WARMUP_S:-0.5}"
elif [[ "${BRIDGE_MODE}" == "ros" ]]; then
  echo "[run_go2real_with_lidar] starting ROS height_scan bridge..."
  python3 "${ROOT_DIR}/tools/height_scan_lidar_bridge.py" \
    --ros-version auto \
    --pointcloud-topic "${PC_TOPIC}" \
    --imu-topic "${IMU_TOPIC}" \
    --udp-host "${UDP_HOST}" \
    --udp-port "${UDP_PORT}" \
    --udp-hz 50 \
    "$@" &
else
  echo "[run_go2real_with_lidar] invalid BRIDGE_MODE=${BRIDGE_MODE}, expected dds|ros"
  exit 1
fi

BRIDGE_PID=$!
cleanup() {
  kill "${BRIDGE_PID}" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

echo "[run_go2real_with_lidar] starting controller on network=${NETWORK_IF} ..."
cd "${BUILD_DIR}"
./go2real_ctrl --network "${NETWORK_IF}"
