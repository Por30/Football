#!/usr/bin/env python3
"""Official-style Unitree utlidar switch publisher.

Publishes "ON"/"OFF" to DDS topic ``rt/utlidar/switch``.
This mirrors unitree_sdk2_python example/go2/high_level/go2_utlidar_switch.py.
"""

import argparse
import sys
import time


def main() -> int:
    parser = argparse.ArgumentParser(description="Publish utlidar switch command to DDS.")
    parser.add_argument("--network", "-n", default="", help="Network interface (e.g. eno1).")
    parser.add_argument("--state", choices=["ON", "OFF"], required=True, help="utlidar target state.")
    parser.add_argument("--topic", default="rt/utlidar/switch", help="DDS switch topic.")
    parser.add_argument("--repeat", type=int, default=3, help="Publish count (default: 3).")
    parser.add_argument("--interval", type=float, default=0.05, help="Interval between publishes (seconds).")
    args = parser.parse_args()

    try:
        from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelPublisher
        from unitree_sdk2py.idl.std_msgs.msg.dds_ import String_
        from unitree_sdk2py.idl.default import std_msgs_msg_dds__String_
    except Exception as exc:
        print(f"[utlidar_switch] import error: {exc}", file=sys.stderr)
        return 2

    if args.network:
        ChannelFactoryInitialize(0, args.network)
    else:
        ChannelFactoryInitialize(0)

    pub = ChannelPublisher(args.topic, String_)
    pub.Init()

    msg = std_msgs_msg_dds__String_()
    msg.data = args.state

    repeat = max(1, int(args.repeat))
    interval = max(0.0, float(args.interval))
    for _ in range(repeat):
        pub.Write(msg)
        if interval > 0.0:
            time.sleep(interval)

    print(
        f"[utlidar_switch] published {args.state} to {args.topic} "
        f"(network={args.network or '<default>'}, repeat={repeat})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
